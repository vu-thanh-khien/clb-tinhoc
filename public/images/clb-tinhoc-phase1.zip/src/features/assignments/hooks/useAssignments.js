import { useState, useEffect, useCallback } from 'react';

// Mock data - Thay bằng API thực tế
const MOCK_ASSIGNMENTS = [
  {
    id: '1',
    title: 'Bài tập 1: Biến và Kiểu dữ liệu',
    description: 'Làm quen với khai báo biến, các kiểu dữ liệu cơ bản trong Python.',
    difficulty: 'easy',
    deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'pending',
    maxScore: 10,
    tags: ['Python', 'Cơ bản'],
    submittedCount: 15,
    totalStudents: 30,
    courseId: 'course-1'
  },
  {
    id: '2',
    title: 'Bài tập 2: Cấu trúc điều khiển',
    description: 'Sử dụng if/else, vòng lặp for và while để giải quyết bài toán.',
    difficulty: 'medium',
    deadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'completed',
    maxScore: 10,
    tags: ['Python', 'Logic'],
    submittedCount: 28,
    totalStudents: 30,
    courseId: 'course-1',
    score: 8.5
  },
  {
    id: '3',
    title: 'Bài tập 3: Hàm và Module',
    description: 'Định nghĩa hàm, tham số, giá trị trả về và import module.',
    difficulty: 'hard',
    deadline: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'overdue',
    maxScore: 10,
    tags: ['Python', 'Nâng cao'],
    submittedCount: 10,
    totalStudents: 30,
    courseId: 'course-1'
  }
];

export const useAssignments = (options = {}) => {
  const { courseId, status, userRole = 'student' } = options;

  const [assignments, setAssignments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch assignments
  useEffect(() => {
    const fetchAssignments = async () => {
      try {
        setIsLoading(true);
        setError(null);

        // TODO: Replace with actual API call
        // const response = await fetch(`/api/assignments?courseId=${courseId}`);
        // const data = await response.json();

        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 500));

        let filtered = [...MOCK_ASSIGNMENTS];

        if (courseId) {
          filtered = filtered.filter(a => a.courseId === courseId);
        }

        if (status) {
          filtered = filtered.filter(a => a.status === status);
        }

        setAssignments(filtered);
      } catch (err) {
        setError(err.message || 'Failed to fetch assignments');
      } finally {
        setIsLoading(false);
      }
    };

    fetchAssignments();
  }, [courseId, status]);

  // Create assignment (Teacher/Admin only)
  const createAssignment = useCallback(async (assignmentData) => {
    try {
      // TODO: API call
      // const response = await fetch('/api/assignments', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(assignmentData)
      // });

      const newAssignment = {
        id: Date.now().toString(),
        ...assignmentData,
        submittedCount: 0,
        totalStudents: 30
      };

      setAssignments(prev => [newAssignment, ...prev]);
      return { success: true, data: newAssignment };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }, []);

  // Update assignment
  const updateAssignment = useCallback(async (id, updates) => {
    try {
      // TODO: API call
      setAssignments(prev => 
        prev.map(a => a.id === id ? { ...a, ...updates } : a)
      );
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }, []);

  // Delete assignment
  const deleteAssignment = useCallback(async (id) => {
    try {
      // TODO: API call
      setAssignments(prev => prev.filter(a => a.id !== id));
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }, []);

  return {
    assignments,
    isLoading,
    error,
    createAssignment,
    updateAssignment,
    deleteAssignment,
    refetch: () => window.location.reload() // Temporary
  };
};

export default useAssignments;
