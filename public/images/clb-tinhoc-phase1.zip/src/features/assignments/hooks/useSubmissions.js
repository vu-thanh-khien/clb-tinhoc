import { useState, useEffect, useCallback } from 'react';

const MOCK_SUBMISSIONS = [
  {
    id: 'sub-1',
    assignmentId: '1',
    studentId: 'HS001',
    studentName: 'Nguyễn Văn A',
    code: 'print("Hello World")\nname = input("Nhập tên: ")\nprint(f"Xin chào {name}")',
    output: 'Hello World\nNhập tên: Test\nXin chào Test',
    submittedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    status: 'pending',
    score: null,
    feedback: ''
  },
  {
    id: 'sub-2',
    assignmentId: '1',
    studentId: 'HS002',
    studentName: 'Trần Thị B',
    code: '# Bài làm của em\nprint("Hello")',
    output: 'Hello',
    submittedAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    status: 'graded',
    score: 8.5,
    feedback: 'Làm tốt! Cần thêm xử lý input.'
  },
  {
    id: 'sub-3',
    assignmentId: '1',
    studentId: 'HS003',
    studentName: 'Lê Văn C',
    code: '',
    output: '',
    submittedAt: null,
    status: 'not_submitted',
    score: null,
    feedback: ''
  }
];

export const useSubmissions = (assignmentId) => {
  const [submissions, setSubmissions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [mySubmission, setMySubmission] = useState(null);

  useEffect(() => {
    const fetchSubmissions = async () => {
      if (!assignmentId) return;

      try {
        setIsLoading(true);
        await new Promise(resolve => setTimeout(resolve, 400));

        const filtered = MOCK_SUBMISSIONS.filter(s => s.assignmentId === assignmentId);
        setSubmissions(filtered);

        // Giả lập tìm bài nộp của user hiện tại (HS001)
        const mine = filtered.find(s => s.studentId === 'HS001');
        setMySubmission(mine || null);
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSubmissions();
  }, [assignmentId]);

  // Submit assignment
  const submitAssignment = useCallback(async (code, output = '') => {
    try {
      const newSubmission = {
        id: `sub-${Date.now()}`,
        assignmentId,
        studentId: 'HS001', // Current user
        studentName: 'Nguyễn Văn A',
        code,
        output,
        submittedAt: new Date().toISOString(),
        status: 'pending',
        score: null,
        feedback: ''
      };

      setSubmissions(prev => [newSubmission, ...prev.filter(s => s.studentId !== 'HS001')]);
      setMySubmission(newSubmission);

      return { success: true, data: newSubmission };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }, [assignmentId]);

  // Grade submission (Teacher only)
  const gradeSubmission = useCallback(async (submissionId, { score, feedback }) => {
    try {
      setSubmissions(prev => 
        prev.map(s => 
          s.id === submissionId 
            ? { ...s, score, feedback, status: 'graded' }
            : s
        )
      );

      if (mySubmission?.id === submissionId) {
        setMySubmission(prev => ({ ...prev, score, feedback, status: 'graded' }));
      }

      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }, [mySubmission]);

  return {
    submissions,
    mySubmission,
    isLoading,
    error,
    submitAssignment,
    gradeSubmission
  };
};

export default useSubmissions;
