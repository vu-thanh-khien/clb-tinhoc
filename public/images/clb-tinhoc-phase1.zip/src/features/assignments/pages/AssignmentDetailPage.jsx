import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Clock, 
  Target, 
  FileText, 
  AlertCircle,
  CheckCircle,
  Send
} from 'lucide-react';
import CodeEditor from '../components/CodeEditor';
import SubmissionList from '../components/SubmissionList';
import GradeFeedback from '../components/GradeFeedback';
import useAssignments from '../hooks/useAssignments';
import useSubmissions from '../hooks/useSubmissions';

const AssignmentDetailPage = ({ userRole = 'student' }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [showGrader, setShowGrader] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState(null);

  // Fetch assignment details
  const { assignments, isLoading: loadingAssignment } = useAssignments();
  const assignment = assignments.find(a => a.id === id);

  // Fetch submissions
  const { 
    submissions, 
    mySubmission, 
    submitAssignment, 
    gradeSubmission,
    isLoading: loadingSubmissions 
  } = useSubmissions(id);

  const handleSubmit = async (code) => {
    const result = await submitAssignment(code);
    if (result.success) {
      alert('Nộp bài thành công!');
    }
  };

  const handleGrade = async (submission) => {
    setSelectedSubmission(submission);
    setShowGrader(true);
  };

  const handleGradeSubmit = async ({ score, feedback }) => {
    const result = await gradeSubmission(selectedSubmission.id, { score, feedback });
    if (result.success) {
      setShowGrader(false);
      setSelectedSubmission(null);
      alert('Chấm điểm thành công!');
    }
  };

  if (loadingAssignment || !assignment) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const isOverdue = new Date(assignment.deadline) < new Date();
  const canSubmit = userRole === 'student' && !isOverdue && !mySubmission;

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <button
        onClick={() => navigate('/assignments')}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Quay lại danh sách
      </button>

      {/* Assignment Header */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                assignment.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                assignment.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                'bg-red-100 text-red-800'
              }`}>
                {assignment.difficulty === 'easy' ? 'Dễ' : 
                 assignment.difficulty === 'medium' ? 'Trung bình' : 'Khó'}
              </span>
              {assignment.tags.map(tag => (
                <span key={tag} className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">
                  {tag}
                </span>
              ))}
            </div>

            <h1 className="text-2xl font-bold text-gray-900 mb-2">{assignment.title}</h1>
            <p className="text-gray-600">{assignment.description}</p>
          </div>

          <div className="flex flex-col gap-2 lg:text-right">
            <div className="flex items-center lg:justify-end gap-2 text-sm">
              <Clock className="w-4 h-4 text-gray-400" />
              <span className={isOverdue ? 'text-red-600 font-medium' : 'text-gray-600'}>
                {isOverdue ? 'Đã hết hạn' : `Hạn: ${new Date(assignment.deadline).toLocaleDateString('vi-VN')}`}
              </span>
            </div>
            <div className="flex items-center lg:justify-end gap-2 text-sm text-gray-600">
              <Target className="w-4 h-4 text-gray-400" />
              <span>{assignment.maxScore} điểm</span>
            </div>
            {userRole === 'student' && mySubmission?.score !== undefined && (
              <div className="flex items-center lg:justify-end gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                <span className="text-lg font-bold text-green-600">
                  {mySubmission.score}/{assignment.maxScore}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Editor or Submission List */}
        <div className="lg:col-span-2 space-y-6">
          {userRole === 'student' ? (
            <>
              {/* Student View: Code Editor */}
              {canSubmit ? (
                <div className="bg-white rounded-xl border border-gray-200 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-600" />
                    Làm bài tập
                  </h3>
                  <CodeEditor 
                    onSubmit={handleSubmit}
                    height="500px"
                  />
                </div>
              ) : mySubmission ? (
                <div className="bg-white rounded-xl border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      Bài đã nộp
                    </h3>
                    <span className="text-sm text-gray-500">
                      Nộp lúc: {new Date(mySubmission.submittedAt).toLocaleString('vi-VN')}
                    </span>
                  </div>
                  <CodeEditor 
                    initialCode={mySubmission.code}
                    readOnly={true}
                    height="400px"
                  />
                  {mySubmission.feedback && (
                    <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-100">
                      <h4 className="font-semibold text-blue-900 mb-1">Nhận xét của giáo viên:</h4>
                      <p className="text-blue-800">{mySubmission.feedback}</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 text-center">
                  <AlertCircle className="w-12 h-12 text-yellow-500 mx-auto mb-3" />
                  <h3 className="text-lg font-semibold text-yellow-900">Đã hết hạn nộp bài</h3>
                  <p className="text-yellow-700 mt-1">Bạn không thể nộp bài sau thời hạn</p>
                </div>
              )}
            </>
          ) : (
            /* Teacher View: Submission List */
            <SubmissionList 
              submissions={submissions}
              assignmentId={id}
              onGrade={handleGrade}
            />
          )}
        </div>

        {/* Right: Sidebar Info */}
        <div className="space-y-6">
          {/* Assignment Info */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Thông tin bài tập</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Trạng thái</span>
                <span className={`font-medium ${
                  assignment.status === 'completed' ? 'text-green-600' :
                  assignment.status === 'pending' ? 'text-yellow-600' :
                  'text-red-600'
                }`}>
                  {assignment.status === 'completed' ? 'Hoàn thành' :
                   assignment.status === 'pending' ? 'Đang chờ' : 'Quá hạn'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Ngôn ngữ</span>
                <span className="font-medium">Python</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Thời gian</span>
                <span className="font-medium">Không giới hạn</span>
              </div>
            </div>
          </div>

          {/* Progress (Teacher) */}
          {userRole === 'teacher' && (
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Tiến độ lớp học</h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Đã nộp</span>
                  <span className="font-medium">{assignment.submittedCount}/{assignment.totalStudents}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full"
                    style={{ width: `${(assignment.submittedCount / assignment.totalStudents) * 100}%` }}
                  />
                </div>
                <div className="flex justify-between text-sm pt-2">
                  <span className="text-gray-500">Chưa nộp</span>
                  <span className="font-medium text-red-600">
                    {assignment.totalStudents - assignment.submittedCount}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* My Score (Student) */}
          {userRole === 'student' && mySubmission?.score !== null && (
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Kết quả của bạn</h3>
              <div className="text-center">
                <div className={`text-4xl font-bold ${
                  mySubmission.score >= 8 ? 'text-green-600' :
                  mySubmission.score >= 5 ? 'text-yellow-600' :
                  'text-red-600'
                }`}>
                  {mySubmission.score}
                </div>
                <div className="text-gray-500 text-sm mt-1">/ {assignment.maxScore} điểm</div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Grade Modal */}
      {showGrader && selectedSubmission && (
        <GradeFeedback
          submission={selectedSubmission}
          onSubmit={handleGradeSubmit}
          onClose={() => {
            setShowGrader(false);
            setSelectedSubmission(null);
          }}
        />
      )}
    </div>
  );
};

export default AssignmentDetailPage;
