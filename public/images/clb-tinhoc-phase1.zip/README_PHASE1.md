# 🚀 Phase 1: Học tập tương tác - CLB Tin học

## 📦 Nội dung đã tạo

### 1. Assignment System (Hệ thống bài tập)
- **AssignmentCard**: Card hiển thị bài tập với difficulty badge, countdown, progress bar
- **CodeEditor**: Editor với syntax highlighting, run code, submit (mock execution)
- **SubmissionList**: Bảng danh sách bài nộp cho giáo viên chấm điểm
- **GradeFeedback**: Modal chấm điểm với score slider, feedback templates

### 2. Progress Tracking (Theo dõi tiến độ)
- **ProgressChart**: Dashboard với stats cards, weekly activity bar chart, subject breakdown
- **Badge**: Achievement badges với progress tracking, unlock animation

### 3. Pages
- **AssignmentsPage**: Danh sách bài tập (grid/list view, filter, stats overview)
- **AssignmentDetailPage**: Chi tiết bài tập + làm bài/nộp bài/chấm điểm
- **CreateAssignmentPage**: Form tạo bài tập đầy đủ (test cases, tags, validation)
- **ProgressPage**: Trang tiến độ cá nhân với badges và activity timeline

### 4. Hooks (Data Fetching)
- **useAssignments**: CRUD operations, filtering, mock data
- **useSubmissions**: Submit assignment, grade submission, track status
- **useProgress**: Stats fetching, completion rate calculation

## 🔧 Hướng dẫn tích hợp

### Bước 1: Cài đặt dependencies

```bash
npm install lucide-react  # Icons (nếu chưa có)
```

### Bước 2: Copy files vào dự án

Copy toàn bộ thư mục `src/features/` vào project của bạn:

```
your-project/
├── src/
│   ├── features/
│   │   ├── assignments/     ← Copy vào đây
│   │   └── progress/       ← Copy vào đây
│   ├── components/ui/       ← Copy Badge.jsx vào đây
│   └── lib/               ← Utils nếu cần
```

### Bước 3: Cấu hình Router

Thêm vào file router chính (App.jsx hoặc routes.jsx):

```jsx
import { createBrowserRouter } from 'react-router-dom';
import { 
  AssignmentsPage, 
  AssignmentDetailPage, 
  CreateAssignmentPage 
} from './features/assignments';
import { ProgressPage } from './features/progress';

const router = createBrowserRouter([
  {
    path: '/assignments',
    element: <AssignmentsPage userRole="student" />  // hoặc "teacher"
  },
  {
    path: '/assignments/create',
    element: <CreateAssignmentPage />
  },
  {
    path: '/assignments/:id',
    element: <AssignmentDetailPage userRole="student" />
  },
  {
    path: '/progress',
    element: <ProgressPage userId="current-user-id" />
  }
]);
```

### Bước 4: Thêm vào navigation

Thêm link vào sidebar/menu hiện tại:

```jsx
import { BookOpen, BarChart2 } from 'lucide-react';

const navItems = [
  { 
    icon: BookOpen, 
    label: 'Bài tập', 
    path: '/assignments' 
  },
  { 
    icon: BarChart2, 
    label: 'Tiến độ', 
    path: '/progress' 
  }
];
```

### Bước 5: Kết nối API (Quan trọng)

Tìm các dòng `// TODO: Replace with actual API` trong hooks và thay bằng API calls thực tế:

**Ví dụ trong useAssignments.js:**
```javascript
// Thay thế:
const fetchAssignments = async () => {
  const response = await fetch('/api/assignments');
  const data = await response.json();
  setAssignments(data);
};

// Hoặc dùng axios:
import axios from 'axios';
const { data } = await axios.get('/api/assignments');
```

## 🎨 Tùy chỉnh giao diện

### Thay đổi màu sắc
Các components sử dụng Tailwind classes. Tìm và thay thế:
- `blue-600` → Màu primary của bạn
- `green-600` → Màu success
- `red-600` → Màu error

### Responsive breakpoints
Mặc định sử dụng:
- `grid-cols-1` (mobile)
- `md:grid-cols-2` (tablet)
- `lg:grid-cols-3` (desktop)

## 🔐 Phân quyền

Truyền prop `userRole` vào pages:
- `student`: Xem bài tập, làm bài, xem tiến độ
- `teacher`: Tất cả của student + Tạo bài tập, chấm điểm, xem thống kê lớp
- `admin`: Toàn quyền

```jsx
// Student view
<AssignmentsPage userRole="student" />

// Teacher view  
<AssignmentsPage userRole="teacher" />
<AssignmentDetailPage userRole="teacher" />
```

## 🧪 Test locally

```bash
npm run dev
```

Truy cập:
- http://localhost:5173/assignments - Danh sách bài tập
- http://localhost:5173/assignments/1 - Chi tiết bài tập
- http://localhost:5173/progress - Tiến độ học tập

## 📝 Checklist tích hợp

- [ ] Copy files vào đúng cấu trúc thư mục
- [ ] Cài đặt lucide-react
- [ ] Thêm routes vào router
- [ ] Thêm navigation links
- [ ] Kết nối API endpoints
- [ ] Test phân quyền (student/teacher)
- [ ] Tùy chỉnh màu sắc theo brand
- [ ] Kiểm tra responsive trên mobile

## 🐛 Xử lý lỗi thường gặp

**Lỗi "Cannot find module"**: Kiểm tra path import, đảm bảo file tồn tại

**Lỗi "useState is not defined"**: Thêm `import React from 'react'` nếu cần

**Code editor không hiển thị**: Kiểm tra CSS height của container

**Không chuyển trang được**: Kiểm tra React Router đã wrap App chưa

## 📞 Hỗ trợ

Nếu gặp vấn đề khi tích hợp:
1. Kiểm tra console errors
2. Verify dependencies đã cài đủ
3. So sánh code với file gốc
4. Test từng component riêng lẻ

---

**Ghi chú**: Code được viết cho React 18+, Vite, Tailwind CSS. Nếu dùng Create React App hoặc Webpack, có thể cần điều chỉnh import paths.
